x=5 
if x==1: 
   print("X = 1") 
elif x==2: 
   print("X = 2") 
elif x==5: 
   print("X = 5") 
else: 
    print("Nijedan od uvjeta nije ispravan!")
